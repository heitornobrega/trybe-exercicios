import React from 'react';
import './App.css';
import Cars from './Cars';

function App() {
  return (
    <Cars />
  );
}

export default App;
